package com.example.atv_media_geral.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.room.util.copy
import com.example.atv_media_geral.model.Aluno

@Composable
fun FormAluno(estadoAluno: MutableState<Aluno>) {
    var nomeInput by remember { mutableStateOf(estadoAluno.value.nome) }
    var nota1 by remember {
        mutableStateOf(
            estadoAluno.value.getNotas().getOrNull(0)?.toString() ?: ""
        )
    }
    var nota2 by remember {
        mutableStateOf(
            estadoAluno.value.getNotas().getOrNull(1)?.toString() ?: ""
        )
    }
    var nota3 by remember {
        mutableStateOf(
            estadoAluno.value.getNotas().getOrNull(2)?.toString() ?: ""
        )
    }

    val media by remember {
        derivedStateOf {
            val n1 = nota1.toDoubleOrNull() ?: 0.0
            val n2 = nota2.toDoubleOrNull() ?: 0.0
            val n3 = nota3.toDoubleOrNull() ?: 0.0
            (n1 + n2 + n3) / 3.0
        }
    }

    val status by remember {
        derivedStateOf {
            when {
                media < 6.0 -> "Reprovado"
                media <= 9.0 -> "Aprovado"
                else -> "Ótimo Aproveitamento"
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp)
    ) {

        OutlinedTextField(
            value = nomeInput,
            onValueChange = { nomeInput = it },
            label = { Text("Nome completo") },
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(12.dp))

        OutlinedTextField(
            value = nota1,
            onValueChange = { nota1 = it },
            label = { Text("TP1") },
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(8.dp))

        OutlinedTextField(
            value = nota2,
            onValueChange = { nota2 = it },
            label = { Text("TP2") },
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(8.dp))

        OutlinedTextField(
            value = nota3,
            onValueChange = { nota3 = it },
            label = { Text("TP3") },
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(16.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = {
                estadoAluno.value.nome = nomeInput
                estadoAluno.value.setNotas(
                    listOf(
                        nota1.toDoubleOrNull() ?: 0.0,
                        nota2.toDoubleOrNull() ?: 0.0,
                        nota3.toDoubleOrNull() ?: 0.0
                    )
                )
                estadoAluno.value = estadoAluno.value.copy()
            }) {
                Text("Salvar")
            }

            Button(onClick = {
                nomeInput = ""
                nota1 = ""
                nota2 = ""
                nota3 = ""
                estadoAluno.value = Aluno()
            }) {
                Text("Limpar")
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Text(text = "Média: ${String.format("%.2f", media)}")
        Spacer(modifier = Modifier.height(4.dp))
        Text(text = "Status: $status")

        Spacer(modifier = Modifier.height(8.dp))
        val notasSalvas = estadoAluno.value.getNotas()
        Text(text = "Notas salvas: ${notasSalvas.joinToString(", ") { String.format("%.2f", it) }}")


    }
}
