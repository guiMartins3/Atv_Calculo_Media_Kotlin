package com.example.atv_media_geral.model

data class Aluno(
    var nome: String = "",
    private val notas: MutableList<Double> = mutableListOf()
) {

    fun setNotas(novasNotas: List<Double>){
        notas.clear()
        notas.addAll(novasNotas.take(3))
        while (notas.size < 3) notas.add(0.0)
    }

    fun getNotas(): List<Double> = notas.toList()

    fun media(): Double{
        if (notas.isEmpty()) return 0.0
        return notas.sum() / notas.size
    }

    fun status(): String {
        val m = media()
        return when {
            m < 6.0 -> "Reprovado"
            m <= 9.0 -> "Aprovado"
            else -> "ótimo Aproveitamento"
        }
    }
}